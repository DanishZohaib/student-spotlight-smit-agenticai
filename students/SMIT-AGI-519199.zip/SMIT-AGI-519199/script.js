document.addEventListener('DOMContentLoaded', () => {
    // --- Theme Switcher ---
    const themeSwitcher = document.querySelector('.theme-switcher');
    const body = document.body;

    themeSwitcher.addEventListener('click', () => {
        body.classList.toggle('dark-mode');
        // Optional: Save theme preference to local storage
        if (body.classList.contains('dark-mode')) {
            localStorage.setItem('theme', 'dark');
        } else {
            localStorage.setItem('theme', 'light');
        }
    });

    // Load theme preference from local storage
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        body.classList.add('dark-mode');
    }

    // --- Smooth Scrolling ---
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    /*
    // --- Optional: Typing Text Animation ---
    const headline = document.querySelector('.headline');
    const text = "Agentic AI Developer | Accountant | AI Explorer";
    let index = 0;

    function type() {
        if (index < text.length) {
            headline.textContent += text.charAt(index);
            index++;
            setTimeout(type, 100); // Adjust typing speed here
        }
    }
    // To use this, uncomment the line below and clear the headline text in index.html
    // headline.textContent = ''; 
    // type();
    */

    /*
    // --- Optional: Preloader ---
    const preloader = document.querySelector('.preloader');
    window.addEventListener('load', () => {
        if (preloader) {
            preloader.style.display = 'none';
        }
    });
    */
});

// Note on Particle.js:
// To enable the particle animation background:
// 1. Uncomment the <div id="particles-js"></div> in index.html.
// 2. Uncomment the particle.js script tag in index.html.
// 3. Create a 'particles.json' file in your project root with your desired particle configuration.
// 4. Uncomment the particlesJS.load call in the script tag at the bottom of index.html.
// You can generate a particles.json file from sites like https://vincentgarreau.com/particles.js/
